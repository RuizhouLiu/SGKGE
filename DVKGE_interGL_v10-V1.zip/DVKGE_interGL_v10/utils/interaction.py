import torch
import torch.nn as nn
import torch.nn.functional as F

from utils import pmath

class InteractionModule(nn.Module):
    def __init__(self, size, n_space, rank, dtype) -> None:
        super(InteractionModule, self).__init__()
        self.n_space = n_space
        self.n_rels = size[1]
        self.n_ent = size[0]
        self.rank = rank
        self.dtype = dtype
        self.beta = nn.Embedding(size[0], n_space * n_space, dtype=dtype)
        self.inter_rels_trans = nn.Embedding(size[1], n_space * n_space * rank, dtype=dtype)

        self._param_init()
    
    def _param_init(self):
        # nn.init.zeros_(self.beta.data)
        nn.init.zeros_(self.beta.weight)
        nn.init.xavier_normal_(self.inter_rels_trans.weight.data)


    def forward(self, lhs_e, rels, lhs, c):
        """
        lhs_e: [batch_size x n_space x rank]
        c: [batch_size x n_space x 1]
        """
        inter_rels_trans = self.inter_rels_trans(rels).view(-1, self.n_space, self.n_space, self.rank)
        beta = self.beta(lhs).view(-1, self.n_space, self.n_space, 1)

        euc_lhs_e = pmath.logmap0(lhs_e, c=c)
        hyp_c_lhs_e = []
        for i_space in range(self.n_space):
            c_i = c[:, i_space].unsqueeze(-1).expand((-1, self.n_space, -1))

            inter_rels_trans_i = pmath.expmap0(inter_rels_trans[:, i_space], c=c_i)
            i_lhs_e = pmath.project(pmath.mobius_add(lhs_e[:, i_space], inter_rels_trans_i[:, i_space], c=c[:, i_space]), c=c[:, i_space]).unsqueeze(1).expand((-1, self.n_space, -1))
            hyp_ci_lhs_e = pmath.project(pmath.mobius_add(pmath.expmap0(euc_lhs_e, c=c_i), inter_rels_trans_i, c=c_i) , c=c_i)
            
            dist = pmath.dist(i_lhs_e, hyp_ci_lhs_e, c=c_i, keepdim=True)
            hyp_ci_lhs_e = beta[:, i_space] * pmath.project(pmath.mobius_scalar_mul(dist, hyp_ci_lhs_e, c=c_i), c=c_i)
            i_lhs_e = pmath.project(pmath.mobius_add(i_lhs_e, hyp_ci_lhs_e, c=c_i), c=c_i).mean(dim=1, keepdim=True)
            
            hyp_c_lhs_e.append(i_lhs_e)

        
        hyp_c_lhs_e = torch.cat(hyp_c_lhs_e, dim=1)

        return hyp_c_lhs_e
