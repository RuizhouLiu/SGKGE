"""Hyperbolic Knowledge Graph embedding models where all parameters are defined in tangent spaces."""
import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

from models.base import KGModel
from utils.euclidean import givens_rotations, givens_reflection
from utils.hyperbolic import mobius_add, expmap0, project, hyp_distance_multi_c, expmapP, expmapH, projectH

HYP_MODELS = ['DVKGE']


class BaseH(KGModel):
    """Trainable curvature for each relationship."""

    def __init__(self, args):
        super(BaseH, self).__init__(args.sizes, args.rank, args.dropout, args.gamma, args.dtype, args.bias,
                                    args.init_size)
        

    def get_rhs(self, queries, eval_mode):
        """Get embeddings and biases of target entities."""
        if eval_mode:
            return self.entity.weight, self.bt.weight
        else:
            return self.entity(queries[:, 2]), self.bt(queries[:, 2])

    def similarity_score(self, lhs_e, rhs_e, eval_mode):
        """Compute similarity scores or queries against targets in embedding space."""
        lhs_e, c = lhs_e
        return - hyp_distance_multi_c(lhs_e, rhs_e, c, eval_mode) ** 2


class DVKGE(BaseH):

    def __init__(self, args):
        super(DVKGE, self).__init__(args)

        self.n_space = args.n_space
        self.entity = nn.Embedding(self.sizes[0], self.rank * self.n_space, dtype=self.data_type)
        self.rel_ref = nn.Embedding(self.sizes[1], self.rank * self.n_space, dtype=self.data_type)
        self.rel_rot = nn.Embedding(self.sizes[1], self.rank * self.n_space, dtype=self.data_type)
        self.rel_trans = nn.Embedding(self.sizes[1], self.rank * self.n_space, dtype=self.data_type)

        # attention
        self.context_vec = nn.Embedding(self.sizes[1], self.rank * self.n_space, dtype=self.data_type)
        if args.dtype == "double":
            self.scale = torch.Tensor([1. / np.sqrt(self.rank * self.n_space)]).double().cuda()
        else:
            self.scale = torch.Tensor([1. / np.sqrt(self.rank * self.n_space)]).cuda()

        # set curvatures params
        self.multi_c = args.multi_c
        if self.multi_c:
            c_init = torch.ones((self.sizes[1], self.n_space), dtype=self.data_type)
        else:
            c_init = torch.ones((1, 1), dtype=self.data_type)
        self.c = nn.Parameter(c_init, requires_grad=True)

        # bias
        self.bh = nn.Embedding(self.sizes[0], 1, dtype=self.data_type)
        self.bt = nn.Embedding(self.sizes[0], 1, dtype=self.data_type)

        self.params_init()
    
    def params_init(self):
        nn.init.xavier_normal_(self.entity.weight.data)
        nn.init.xavier_normal_(self.rel_ref.weight.data)
        nn.init.xavier_normal_(self.rel_rot.weight.data)
        nn.init.xavier_normal_(self.rel_trans.weight.data)
        nn.init.xavier_normal_(self.context_vec.weight.data)
        nn.init.zeros_(self.bh.weight.data)
        nn.init.zeros_(self.bt.weight.data)
        
    
    def get_queries(self, queries):
        c = F.softplus(self.c[queries[:, 1]]).view(-1, self.n_space, 1)
        head = self.entity(queries[:, 0])
        rel_ref = self.rel_ref(queries[:, 1])
        rel_rot = self.rel_rot(queries[:, 1])
        rel_trans = self.rel_trans(queries[:, 1])

        rot_q = givens_rotations(rel_rot, head).view((-1, 1, self.rank))
        ref_q = givens_reflection(rel_ref, head).view((-1, 1, self.rank))
        context_vec = self.context_vec(queries[:, 1]).view((-1, 1, self.rank))

        cands = torch.cat([ref_q, rot_q], dim=1)
        att_weights = torch.sum(context_vec * cands * self.scale, dim=-1, keepdim=True)
        att_weights = F.softmax(att_weights, dim=1)
        att_q = torch.sum(att_weights * cands, dim=1)

        att_q = att_q.view(-1, self.n_space, self.rank)
        rel_trans = rel_trans.view(-1, self.n_space, self.rank)

        att_q_H = expmap0(att_q, c)
        rel_trans_H = expmap0(rel_trans, c)

        res = project(mobius_add(att_q_H, rel_trans_H, c), c)

        return (res, c), self.bh(queries[:, 0])

    def get_rhs(self, queries, eval_mode):
        """Get embeddings and biases of target entities."""
        if eval_mode:
            return self.entity.weight.view(-1, self.n_space, self.rank), self.bt.weight
        else:
            return self.entity(queries[:, 2]).view(-1, self.n_space, self.rank), self.bt(queries[:, 2])

    def similarity_score(self, lhs_e, rhs_e, eval_mode):
        """Compute similarity scores or queries against targets in embedding space."""
        lhs_e, c = lhs_e
        return - hyp_distance_multi_c(lhs_e, rhs_e, c, eval_mode) ** 2

    def get_factors(self, queries):
        head_e = self.entity(queries[:, 0])
        rel_e = torch.cat([
            self.rel_ref(queries[:, 1]), self.rel_rot(queries[:, 1]), self.rel_trans(queries[:, 1])
            ], dim=-1)
        rhs_e = self.entity(queries[:, 2])
        return head_e, rel_e, rhs_e


