#!/bin/bash
wget https://dl.fbaipublicfiles.com/kbc/data.tar.gz
tar -xvzf data.tar.gz
rm data.tar.gz
